//
//  MyCollectionCell.swift
//  ScrollView
//
//  Created by Junyoung_Hong on 2022/07/26.
//

import UIKit

class MyCollectionCell: UICollectionViewCell {
    @IBOutlet var thumbNail: UIImageView!
    
}
